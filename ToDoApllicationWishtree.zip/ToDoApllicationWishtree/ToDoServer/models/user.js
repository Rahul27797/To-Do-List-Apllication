const user = {
    name: 'Jackator',
    // ...
    roles: ['user'],
    rights: ['can_view_articles']
  };