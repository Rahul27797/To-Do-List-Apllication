const mongoose = require("mongoose");
//creating schema foe userdetails.
var UserSchema = new mongoose.Schema({
    firstName : String,
    lastName : String,
    gender :String, 
    age : Number,
    dateOfBirth : {type:Date},
    dateOfSignup:{type:Date,default : Date.now},
    email : {type:String,unique:true,required: [true, "can't be blank"]},
    password : {type:String,required: [true, "can't be blank"]},
    cpassword : {type:String,required: [true, "can't be blank"]},
    isAdmin : {type : Boolean ,default : false},
    isActive : {type : Boolean },
    isConfirmed : {type : Boolean},
})


var userdetails = mongoose.model("userdetails",UserSchema) ;
//exporting the userdetails model
module.exports = {userdetails};