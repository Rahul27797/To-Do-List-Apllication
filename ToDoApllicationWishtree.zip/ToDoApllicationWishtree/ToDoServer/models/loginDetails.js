const mongoose = require("mongoose");
//creating schema foe Login details.
var LoginSchema = new mongoose.Schema({
    firstname : String,
    userId : [
        {type: mongoose.Schema.Types.ObjectId,ref:'userdetails'}
    ],
    email : String,
    lastLoginDate:{type:Date,default : Date.now}
});

var logindetails = mongoose.model("lastlogins",LoginSchema) ;

module.exports = {logindetails};