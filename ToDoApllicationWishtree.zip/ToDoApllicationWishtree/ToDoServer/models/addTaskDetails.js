const mongoose = require("mongoose");
//creating schema for task details
var taskListSchema = new mongoose.Schema({
    firstName : String,
    lastName : String,
    userId : 
    [
        {type: mongoose.Schema.Types.ObjectId,ref:'userdetails'}
    ],
    title : String,
    discription : String,
    email : String,
    dateOfAdddingTask:{type:Date,default : Date.now},
    status : Boolean
})

var taskListdetails = mongoose.model("tasklists",taskListSchema) ;

module.exports = {taskListdetails};