import React, { Component } from 'react'
//Home page By Default Page
export class Home extends Component {
    render() {
        return (
            <div>
                <h1 className="text-center-align">Welcome To</h1>
                <h4>To Do List Appllication</h4>
            </div>
        )
    }
}

export default Home


